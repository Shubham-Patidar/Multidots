<?php
/**

 * Plugin Name: Guest Post/Page Submission Plugin 

 * Author: Shubham Patidar

 * Description: Simple plugin for create custom post from frontend form and list post

 * Version:1.0.0

 */


 class Guestpostplugin {

    public function __construct(){

//create shortcode for form creation 

  add_shortcode( 'custom_form',array( $this,'customFormFunction'));
  // --------- post listing --------------
  add_shortcode( 'post_listing',array( $this,'postListingFunction'));


   //  Ajax Function Start Here
  add_action('wp_ajax_nopriv_customform_action',array( $this,"create_post_function"));
  add_action('wp_ajax_customform_action',array( $this,"create_post_function"));
//  Ajax Function End Here


    }


  function customFormFunction(){

    if (  is_user_logged_in() ) {

    ob_start();

    include_once plugin_dir_path(__file__)."/templates/CustomFormPage.php";

    $contents = ob_get_contents();
    ob_end_clean();

echo $contents;
    }
  }
  

  function postListingFunction(){

    ob_start();

    include_once plugin_dir_path(__file__)."/templates/PostListingPage.php";

    $contents = ob_get_contents();
    ob_end_clean();

echo $contents;
    
  }
// ------- post listing page -----------



function create_post_function(){

$user_id = get_current_user_id();

$post_title = $_POST['post_title'];
$description = $_POST['description'];
$excerpt = $_POST['excerpt'];

$post_data = array(
        'post_title' => $post_title,
        'post_content' => $description,
        'post_excerpt' => $excerpt,
        'post_status' => 'publish', 
        'post_author' => $user_id,
        'post_type' => 'blog', 
    );

  $post_id=wp_insert_post( $post_data );
      
$wordpress_upload_dir = wp_upload_dir();

$i = 1; 

$portfolio_image = $_FILES['portfolio_image'];
$new_file_path = $wordpress_upload_dir['path'] . '/' . $portfolio_image['name'];
$new_file_mime = mime_content_type( $portfolio_image['tmp_name'] );

if( empty( $portfolio_image ) )
    die( 'File is not selected.' );

if( $portfolio_image['error'] )
    die( $portfolio_image['error'] );
    
if( $portfolio_image['size'] > wp_max_upload_size() )
    die( 'It is too large than expected.' );
    
if( !in_array( $new_file_mime, get_allowed_mime_types() ) )
    die( 'WordPress doesn\'t allow this type of uploads.' );
    
while( file_exists( $new_file_path ) ) {
    $i++;
    $new_file_path = $wordpress_upload_dir['path'] . '/' . $i . '_' . $portfolio_image['name'];
}

if( move_uploaded_file( $portfolio_image['tmp_name'], $new_file_path ) ) {
    

    $upload_id = wp_insert_attachment( array(
        'guid'           => $new_file_path, 
        'post_mime_type' => $new_file_mime,
        'post_title'     => preg_replace( '/\.[^.]+$/', '', $portfolio_image['name'] ),
        'post_content'   => '',
        'post_status'    => 'inherit'
    ), $new_file_path );

    require_once( ABSPATH . 'wp-admin/includes/image.php' );
    
    wp_update_attachment_metadata( $upload_id, wp_generate_attachment_metadata( $upload_id, $new_file_path ) );

   $success = set_post_thumbnail( $post_id, $upload_id );
   
   $update = update_post_meta($post_id,'admin_aprove',0);        
 
    $to = get_option('admin_email');
    $subject = 'Created New Post';
    $message = $post_title;

   wp_mail(  $to, $subject,$message,'', array() );

  echo 1;
  die();

}
}



}

$sobj = new Guestpostplugin();
