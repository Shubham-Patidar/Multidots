<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<style type="text/css">
    .link a{color:blue;}
</style>
<div id="container" style="margin-left: 5%;margin-right: 5%;">
<div id="content" role="main">
    <div class="row">
    <h3 style="text-align: center;">Post Listing</h3>
<?php

$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

$args = array( 'posts_per_page' => 4,'paged' => $paged,'post_type' => 'blog' );

    $postslist = new WP_Query( $args );

    if ( $postslist->have_posts() ) :
        while ( $postslist->have_posts() ) : $postslist->the_post(); 
        $id = get_the_id();
        $images = get_the_post_thumbnail_url( $id,  'post-thumbnail' );
          ?>

    <div class="col-sm-3" style="margin-top: 3%;">
    <img src="<?=$images;?>" style="height: 200px; width: 90%;">    
    <h5><?php the_title();?></h5>    
    <p><?php the_content();?></p>
    
    </div>

    <?php 
         endwhile;  
?>
</div>
<div class="row">
    <div class="col-sm-3 link" style="float: right;">
<?php
             next_posts_link( '<h4><b>Previous Entries</b></h4>', $postslist->max_num_pages );
             previous_posts_link( 'Next Entries &raquo;' ); 
        wp_reset_postdata();
    endif;
    ?>
</div>
</div>
</div><!-- #content -->
</div><!-- #container -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>