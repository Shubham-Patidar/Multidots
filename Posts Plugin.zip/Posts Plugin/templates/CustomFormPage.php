	  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
            
            <div class="row" style="height: 100px;">
				<div class="col-12 col-lg-12"></div>
			</div>
  
            <div class="row">
				<div class="col-12 col-lg-12">
					<h2 style="text-align: center;">Cusotm Post Form</h2>
				</div>
			</div> 
	<section>
		<div>
			<?php if($_GET['login']=='failed'){ ?>
			<div class="row animate anim-fadein">
				<div class="col-3 col-lg-3"></div>
				<div class="col-6 col-lg-6">
					<h6 style="color: #ff0000;">User and email alreay exist</h6>
				</div>
			</div>
		<?php } ?>
			<div class="row animate anim-fadein">
				<div class="col-3 col-lg-3"></div>
				<div class="col-6 col-lg-6 content-col">
			<form action="<?php $_PHP_SELF?>"  id="custom-form" name="custom-form" method="post" enctype="multipart/form-control">
				 <input type="hidden" name="action" value="customform_action">
				 <input type="text" name="post_title" id="post_title" class="form-control" placeholder="Title" required>
				 <br>
				 <textarea name="description" id="description" class="form-control" placeholder="Description" required></textarea>
				 <br>
				 <textarea name="excerpt" id="excerpt" class="form-control" placeholder="Excerpt" required></textarea>
				 <br>
				<input type="file" name="portfolio_image" id="image" class="form-control" accept="image/*" style="width: 100%;" required>
                 <br>
                 <input type="submit" id="submit" class="btn btn-success">

			</form>	
			
				</div>
			</div>
		</div>
	</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

    <!-- include_once plugin_dir_path(__FILE__)."templates/CustomFormPage.php"; -->

<script type="text/javascript">
	jQuery(document).ready(function(){
    jQuery("#custom-form").submit(function(event){

    	var url =" <?php echo site_url().'/wp-admin/admin-ajax.php';?>";
    	event.preventDefault();
        var formData = new FormData(this);
        // console.log(formData);
          jQuery.ajax({
             url: url,
             type: 'POST',
             data: formData,
             async: false,
             success: function(data) {
               console.log(data);
               if(data==1){
               	alert('Post create successful');
               	$("#custom-form")[0].reset();
                 }

            },
            cache: false,
            contentType: false,
            processData: false
        });
     });
});
</script>